from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Account, Profile


class AccountAdmin(UserAdmin):
    list_display = ('email', 'slug', 'is_active', 'username', 'is_employer', 'is_employee')
    search_fields = ('email', 'username',)
    readonly_fields = ("id", "date_joined", "last_login", 'is_superuser')

    filter_horizontal = ()
    list_filter = ()
    fieldsets = ()

    # Disables the editing of the username field
    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        is_superuser = request.user.is_superuser
        disabled_fields = set()

        if not is_superuser:
            form.base_fields['username'].disabled = True

        return form

    # Prevents staff users from deleting models instances
    def has_delete_permission(self, request, obj=None):
        return False



admin.site.register(Account, AccountAdmin)
admin.site.register(Profile)