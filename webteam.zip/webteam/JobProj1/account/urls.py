from django.contrib.auth import views as auth_views
from django.urls import path
from account.views import (employer_register_view, 
                            account_activate, logout_view, 
                            login_view,
                            employee_register_view, EmployeesAccountDetailView,
                            EmployersAccountDetailView, EmployersAccountUpdateView
                        )

from django.views.generic import TemplateView
from .views import PasswordResetView
from .forms import PwdResetConfirmForm, PwdResetForm

app_name = 'account'

urlpatterns = [
     # Authentication
    path('employer/register/', employer_register_view, name='employer-register-view'),
    path('employee/register/', employee_register_view, name='employee-register-view'),
    path('activate/<slug:uidb64>/<slug:token>)/', account_activate, name='activate'),
    path('logout/', logout_view, name='logout-view'),
    path('login/', login_view, name='login-view'),

     # Accounts and Profiles
     path('<int:pk>/', EmployeesAccountDetailView.as_view(), name='employees-account-detail-view'),
     # path('list/', )
     path('employers/<int:pk>/', EmployersAccountDetailView.as_view(), name='employers-account-detail-view'),

    
    # Reset password
    path('password_reset/', PasswordResetView.as_view(template_name="account/user/password_reset_form.html",
                                                                 success_url='password_reset_email_confirm',
                                                                 email_template_name='account/user/password_reset_email.html',
                                                                 form_class=PwdResetForm), name='pwdreset',),

    path('password_reset_confirm/<uidb64>/<token>', auth_views.PasswordResetConfirmView.as_view(template_name='account/user/password_reset_confirm.html',
                                                                                                success_url='password_reset_complete/',
                                                                                                form_class=PwdResetConfirmForm),
         name="password_reset_confirm"),

    path('password_reset/password_reset_email_confirm/',
         TemplateView.as_view(template_name="account/user/reset_status.html"), name='password_reset_done'),
    
    path('password_reset_confirm/MQ/password_reset_complete/',
         TemplateView.as_view(template_name="account/user/reset_status.html"), name='password_reset_complete'),
    path('password_reset_confirm/Mg/password_reset_complete/',
         TemplateView.as_view(template_name="account/user/reset_status.html"), name='password_reset_complete'),
    path('password_reset_confirm/Mw/password_reset_complete/',
         TemplateView.as_view(template_name="account/user/reset_status.html"), name='password_reset_complete'),
    path('password_reset_confirm/NA/password_reset_complete/',
         TemplateView.as_view(template_name="account/user/reset_status.html"), name='password_reset_complete'),
    path('password_reset_confirm/NQ/password_reset_complete/',
         TemplateView.as_view(template_name="account/user/reset_status.html"), name='password_reset_complete'),
]