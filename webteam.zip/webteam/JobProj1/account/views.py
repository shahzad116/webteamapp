import os
import json
import base64

from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, JsonResponse, HttpResponseRedirect
from django.contrib.auth import login, authenticate, logout
from django.conf import settings
from django.forms.models import model_to_dict
from django.views.generic import View, CreateView, DetailView, ListView
from django.utils.http import is_safe_url
from django.contrib.auth.decorators import login_required
from django.core import files
from django.core.files.storage import default_storage
from django.core.files.storage import FileSystemStorage
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.contrib.auth.mixins import UserPassesTestMixin
from django.contrib.auth.views import PasswordResetView
from django.views.generic import ListView, DetailView, UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic.list import MultipleObjectMixin

from account.forms import ( EmployerRegistrationForm, 
                            AccountAuthenticationForm, 
                            EmployeeRegistrationForm, 
                            EmployersAccountUpdateForm
                        )

from account.models import Account, Profile
from account.tokens import account_activation_token


def get_redirect_if_exists(request):
    # redirect = None
    redirect = settings.LOGIN_REDIRECT_URL
    if request.GET:
        if request.GET.get("next"):
            redirect = str(request.GET.get("NEXT"))
    return redirect

def logout_view(request):
    logout(request)
    return redirect('public:home-view')


def login_view(request, *args, **kwargs):
    context = {}
    user = request.user
    if user.is_authenticated:
        return redirect("public:home-view")

    if request.POST:
        form = AccountAuthenticationForm(request.POST)
        if form.is_valid():
            email = request.POST['email']
            password = request.POST['password']
            user = authenticate(email=email, password=password)

            if user:
                login(request, user)
                if request.GET:
                    if request.GET.get("next"):
                        return redirect(request.GET.get('next'))
                return redirect("public:home-view")
    else:
        form = AccountAuthenticationForm()
    context['login_form'] = form
    return render(request, "account/login.html", context)


def employer_register_view(request, *args, **kwargs):
    context = {}
    if request.user.is_authenticated:
        return redirect('public:home-view')

    if request.method == 'POST':
        employer_register_form = EmployerRegistrationForm(request.POST)
        if employer_register_form.is_valid():
            user = employer_register_form.save(commit=False)
            user.email = employer_register_form.cleaned_data['email']
            user.set_password(employer_register_form.cleaned_data['password1'])
            user.is_active = False
            user.is_employer = True
            user.save()
            current_site = settings.BASE_URL
            subject = 'Activate your Account'
            message = render_to_string('account/registration/account_activation_email.html', {
                'user': user,
                'domain': current_site,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': account_activation_token.make_token(user),
            })
            user.email_user(subject=subject, message=message)
            return HttpResponse('registered succesfully and activation sent')
            
    else:
        employer_register_form = EmployerRegistrationForm()
    context['employer_register_form'] = employer_register_form
    return render(request, 'account/employer-register.html', context)

def employee_register_view(request, *args, **kwargs):
    context = {}
    if request.user.is_authenticated:
        return redirect('public:home-view')

    if request.method == 'POST':
        employee_register_form = EmployeeRegistrationForm(request.POST)
        if employee_register_form.is_valid():
            user = employee_register_form.save(commit=False)
            user.email = employee_register_form.cleaned_data['email']
            user.set_password(employee_register_form.cleaned_data['password1'])
            user.is_active = False
            user.is_employee = True
            user.save()
            current_site = settings.BASE_URL
            subject = 'Activate your Account'
            message = render_to_string('account/registration/account_activation_email.html', {
                'user': user,
                'domain': current_site,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': account_activation_token.make_token(user),
            })
            user.email_user(subject=subject, message=message)
            return HttpResponse('registered succesfully and activation sent')
            
    else:
        employee_register_form = EmployeeRegistrationForm()
    context['employee_register_form'] = employee_register_form
    return render(request, 'account/employee-register.html', context)


def account_activate(request, uidb64, token):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        user = Account.objects.get(pk=uid)
    except(TypeError, ValueError, OverflowError, user.DoesNotExist):
        user = None
    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        login(request, user)
        return redirect('public:home-view')
    else:
        return render(request, 'account/activation_invalid.html')


class PasswordResetView(PasswordResetView):

   def dispatch(self, *args, **kwargs):
       if self.request.user.is_authenticated:
           return redirect('public:home-view')
       return super().dispatch(*args, **kwargs)


class EmployeesAccountDetailView(DetailView):
    model = Account
    context_object_name = 'account'
    template_name = 'account/profile/employees-profile.html'
    
    def get_queryset(self):
        """Returns Only published posts """
        return Account.active_employees_account.all()


class EmployersAccountDetailView(DetailView):
    model = Account
    context_object_name = 'account'
    template_name = 'account/profile/employers-profile.html'
    
    def get_queryset(self):
        """Returns Only published posts """
        return Account.active_employers_account.all()


class EmployersAccountUpdateView(UpdateView):
    model = Account
    # fields = ('message', )
    template_name = 'account/profile/employers-account-update.html'
    # pk_url_kwarg = 'post_pk'
    context_object_name = 'account'

    def form_valid(self, form):
        post = form.save(commit=False)
        post.updated_by = self.request.user
        post.save()
        # return redirect('topic_posts', pk=post.topic.board.pk, topic_pk=post.topic.pk)
