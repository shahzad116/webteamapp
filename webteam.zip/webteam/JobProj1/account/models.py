from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.conf import settings
from django.shortcuts import reverse
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.core.exceptions import ValidationError
from django.utils.translation import gettext as _
# from django.contrib.auth.models import User
from django.core.mail import send_mail

from autoslug import AutoSlugField

import os


class CustomAccountManager(BaseUserManager):
    def create_superuser(self, email, username, password):
        user = self.create_user(
            email = self.normalize_email(email),
            username = username,
            password = password,
        )
        user.is_admin = True
        user.is_staff = True
        user.is_superuser = True
        user.save(using = self._db)
        return user
    
    def create_user(self, email, username, password=None):
        if not email:
            raise ValueError("Users must have an email address")
        if not username:
            raise ValueError("Users must have a Username")
        
        user = self.model(
            email = self.normalize_email(email),
            username = username,
        )
        user.set_password(password)
        user.save(using=self._db)
        return user



class LowercaseCharField(models.CharField):
    """
    Override CharField to convert to lowercase before saving.
    """
    def to_python(self, value):
        """
        Convert text to lowercase.
        """
        value = super(LowercaseCharField, self).to_python(value)
        # Value can be None so check that it's a string before lowercasing.
        if isinstance(value, str):
            return value.lower()
        return value


class ActiveEmployeesAccountManager(models.Manager):
    def get_queryset(self):
        return super(ActiveEmployeesAccountManager, self).get_queryset().filter(is_active=True).filter(is_employee=True)

class ActiveEmployersAccountManager(models.Manager):
    def get_queryset(self):
        return super(ActiveEmployersAccountManager, self).get_queryset().filter(is_active=True).filter(is_employer=True)


class Account(AbstractBaseUser, PermissionsMixin):
    
    SEX_CHOICES = (
        ('M', 'Male',),
        ('F', 'Female',),
    )

    email = models.EmailField(verbose_name='email', max_length=50, unique=True)
    username = models.CharField(max_length=20)
    slug = AutoSlugField(populate_from='username', unique=True)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    sex = models.CharField(max_length=10, choices=SEX_CHOICES)
    is_employer = models.BooleanField(default=False)
    is_employee = models.BooleanField(default=False)
    phonenumber = models.CharField(max_length=50)
    date_joined = models.DateTimeField(verbose_name="date joined", auto_now_add=True)
    last_login = models.DateTimeField(verbose_name="last login", auto_now=True)
    is_admin = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    
    objects = models.Manager() 
    active_employees_account = ActiveEmployeesAccountManager()
    active_employers_account = ActiveEmployersAccountManager()

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["username",]

    objects = CustomAccountManager()

    def __str__(self):
        return self.username


    def get_employees_absolute_url(self):
        return reverse('account:employees-account-detail-view', kwargs={'pk': self.id})

    def get_employers_absolute_url(self):
        return reverse('account:employers-account-detail-view', kwargs={'pk': self.id})


 	# To be sure of admin permissions, Note: all admins have permissions
    def has_perm(self, perm, obj=None):
        return self.is_admin

	# Does this user have permission to view this app? (ALWAYS YES FOR SIMPLICITY)
    def has_module_perms(self, app_label):
        return True

    def email_user(self, subject, message):
        send_mail(
            subject,
            message,
            settings.BASE_EMAIL,
            [self.email],
            fail_silently=False,
        )


class Profile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    bio = models.CharField(max_length=100, blank=True)
    image = models.ImageField(max_length=255, upload_to='profile-image', null=True, blank=True)
    date_created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        # return self.user.first_name + " " + self.user.last_name
        return self.user.username

    class Meta:
        verbose_name_plural = 'Profiles'

    
    # def get_absolute_url(self):
    #     return reverse('blog:post-detail-view', kwargs={'slug': self.slug})


def profile_receiver(sender, instance, created, *args, **kwargs):
    if created:
        profile = Profile.objects.create(user=instance)

post_save.connect(profile_receiver, sender=settings.AUTH_USER_MODEL)

