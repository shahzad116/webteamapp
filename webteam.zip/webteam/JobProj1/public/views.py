from django.shortcuts import render
from account.models import Account


def home_view(request):
    # employees_profile = Profile.objects.all()
    employees_account = Account.active_employees_account.all()
    employers_account = Account.active_employers_account.all()
    context = {
        "employees_account": employees_account,
        "employers_account": employers_account,
    }
    return render(request, 'public/home.html', context)


# class BookListView(ListView):
#     model = Profile
#     context_object_name = 'profile_list'
#     template_name = 'account/profile/profile.html'